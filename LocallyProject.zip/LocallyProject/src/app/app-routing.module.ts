import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomePageComponent } from './home-page/home-page.component';
import { AboutPageComponent } from './about-page/about-page.component';
import { ContactPageComponent } from './contact-page/contact-page.component';
import { PlacesPageComponent } from './places-page/places-page.component';
import { DetailsPageComponent } from './details-page/details-page.component';
import { AdminPageComponent } from './admin-page/admin-page.component';

const routes: Routes = [
{ path:  'About', component:  AboutPageComponent},
{ path:  'Contact', component:  ContactPageComponent},
{ path:  'Places', component:  PlacesPageComponent},
{ path:  'Detail', component:  DetailsPageComponent},
{ path:  'Admin', component:  AdminPageComponent},
{ path:  '', component:  HomePageComponent},
{ path:  '**', component:  HomePageComponent},
{ path:  'Detail/:id', component:  DetailsPageComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
