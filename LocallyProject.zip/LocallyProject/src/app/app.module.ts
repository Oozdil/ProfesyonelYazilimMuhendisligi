import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavMenuComponent } from './nav-menu/nav-menu.component';
import { FooterComponent } from './footer/footer.component';
import { PageContainerComponent } from './page-container/page-container.component';
import { HomePageComponent } from './home-page/home-page.component';
import { AboutPageComponent } from './about-page/about-page.component';
import { ContactPageComponent } from './contact-page/contact-page.component';
import { PlacesPageComponent } from './places-page/places-page.component';
import { DetailsPageComponent } from './details-page/details-page.component';
import { AdminPageComponent } from './admin-page/admin-page.component';
import { SliderComponent } from './slider/slider.component';
import { ModalsComponent } from './modals/modals.component';
import {HttpClientModule} from '@angular/common/http';




@NgModule({
  declarations: [
    AppComponent,
    NavMenuComponent,
    FooterComponent,
    PageContainerComponent,
    HomePageComponent,
    AboutPageComponent,
    ContactPageComponent,
    PlacesPageComponent,
    DetailsPageComponent,
    AdminPageComponent,
    SliderComponent,
    ModalsComponent,
  

  
 
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
