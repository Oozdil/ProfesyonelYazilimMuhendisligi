export class Description
{
id:number;
content:string;

}