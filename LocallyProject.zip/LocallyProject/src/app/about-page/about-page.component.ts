import { Component, OnInit } from '@angular/core';
import { HttpClientModule,HttpClient} from '@angular/common/http';
import { TeamMember } from './teammember';
import { NgModule } from '@angular/core';
import { Description } from './description';



@Component({
  selector: 'app-about-page',
  templateUrl: './about-page.component.html',
  styleUrls: ['./about-page.component.css'],
})

@NgModule({
  imports:[
    HttpClientModule
  ]
})
export class AboutPageComponent implements OnInit {

  constructor(private http:HttpClient) { } 

 baslik1="Proje Hakkında"
 baslik2="Proje Ekibi"
 
 projectdescription="No Content";

  teammembers:any[]=[ ]
  descriptions:any[]=[]
  
  ngOnInit() {
    this.http.get<TeamMember[]>("http://localhost:3000/teammembers").subscribe(data=>{
    this.teammembers=data;
    });

    this.http.get<Description[]>("http://localhost:3000/projectDescription").subscribe(data=>{
    this.descriptions=data;
    });
  }
 
}
