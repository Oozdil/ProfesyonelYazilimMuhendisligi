export class TeamMember
{
id:number;
name:string;
description:string;

}