import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-places-page',
  templateUrl: './places-page.component.html',
  styleUrls: ['./places-page.component.css']
})
export class PlacesPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
