import { Component, OnInit } from '@angular/core';
import { HttpClientModule,HttpClient} from '@angular/common/http';
import { Slider } from './slider';
import { NgModule } from '@angular/core';


@NgModule({
  imports:[
    HttpClientModule
  ]
})
@Component({
  selector: 'app-slider',
  templateUrl: './slider.component.html',
  styleUrls: ['./slider.component.css']
})
export class SliderComponent implements OnInit {

  constructor(private http:HttpClient) { } 

  sliders:any[]=[ ]
  
  ngOnInit() {
    this.http.get<Slider[]>("http://localhost:3000/sliders").subscribe(data=>{
    this.sliders=data;
    });

 
  }


}
