export class Slider
{
id:number;
imgSrc:string;
title:string;
content:string;
}